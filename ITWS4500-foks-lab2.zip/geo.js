$(document).ready(function(e) {

	function displayLocation(position) {

		$.ajax({
			type: "GET",
			url: 'https://api.forecast.io/forecast/a38bcb218cc3b2a70381347c2e389ab2/'+ position.coords.latitude +',' + position.coords.longitude,
			dataType: "jsonp",
		 
			success: function(responseData, status) {
		
		
				//setting up my variables to display current real time weather data
				var locale = responseData['timezone'];
				var current_temp = responseData['currently']['temperature'];
				var summary= responseData['currently']['summary'];
				var humidity= responseData['currently']['humidity'];
				var icon= responseData['currently']['icon'];
				var windspeed= responseData['currently']['windSpeed'];
				
				$("#current"+  " [name=usersLocation]").html(locale);
				$("#current"+  " [name=temperature]").html(current_temp+" Celsius");
				$("#current"+ " [name=summary]").html(summary);
				$("#current"+ " .iconinfo [name=humidity]").html("Humidity is "+humidity);
				$("#current"+ " .iconinfo [name=icon]").html(icon);
				$("#current"+  " .iconinfo [name=windSpeed]").html("Windspeed "+windspeed + " mph");
				
				//depending on what the weather is a different icon representation will take place
				if((icon==="snow")||(icon==="light snow")||(icon==="Flurries")||(icon==="Mixed precipitation")){
					
					$("#current [name=iconimage]").html("<img src='snow.png'>");
				}
				else if((icon==="partly-cloudy-day")||(icon==="partly-cloudy-night")||(icon==="Partly cloudy")){
					$("#current [name=iconimage]").html("<img src='cloudy.png'>"); 
					
				}
				else if((icon==="clear-day")||(icon==="clear")){
					$("#current [name=iconimage]").html("<img src='sunny.png'>");
				
				}
				else if((icon==="rain")||(icon==="drizzle")){
			
					$("#current [name=iconimage]").html("<img src='rain.png'>");
				}
				
				
				//display information to correct class and div
				for (var i=0; i<4;i++){
					var locale = responseData['timezone'];
					var current_temp=responseData['daily']['data'][i]['temperatureMax'];
					var summary= responseData['daily']['data'][i]['summary'];
					var humidity= responseData['daily']['data'][i]['humidity'];
					var icon= responseData['daily']['data'][i]['icon'];
					var windspeed= responseData['daily']['data'][i]['windSpeed'];
						
						
					$("#"+i +" [name=usersLocation]").html(locale);
					$("#"+i +" [name=temperature]").html(current_temp+" Celsius");
					$("#"+i +" [name=summary]").html(summary);
					$("#"+i +" .iconinfo [name=humidity]").html("Humidity is "+humidity);
					$("#"+i +" .iconinfo [name=icon]").html(icon);
					$("#"+i +" .iconinfo [name=windSpeed]").html("Windspeed "+windspeed + " mph");
					
					
					//depending on what the weather is a different icon representation will take place
					if((icon==="snow")||(icon==="light snow")||(icon==="Flurries")||(icon==="Mixed precipitation")){
					
						$("#"+i +" [name=iconimage]").html("<img src='snow.png'>");
					}
					else if((icon==="partly-cloudy-day")||(icon==="partly-cloudy-night")||(icon==="Partly cloudy")){
				
						$("#"+i +" [name=iconimage]").html("<img src='cloudy.png'>");
					}
					else if((icon==="clear-day")||(icon==="clear")){
					
						$("#"+i +" [name=iconimage]").html("<img src='sunny.png'>");
					}
					else if((icon==="rain")||(icon==="drizzle")){
			
						$("#"+i +" [name=iconimage]").html("<img src='rain.png'>");
						
					}
				}
				
				futureweather(0);
				//removes the oldest div and then appends it and redisplays it like a tweet
				function futureweather(i){
					
					var removed;
	
					removed = $('#'+i);
					$('#'+i).remove();
					
					$('#future_forecast').append(removed);
					setTimeout(function() {futureweather((i+1)%4)}, 3000);
					
				}
			}, 
		
			error: function(msg) {
				alert("There was a problem: " + msg.status + " " + msg.statusText);
			}	
	   });
	}
	
	function showError(error) {
		switch(error.code) {
			case error.PERMISSION_DENIED:
				x.innerHTML = "User denied the request for Geolocation."
				break;
			case error.POSITION_UNAVAILABLE:
				x.innerHTML = "Location information is unavailable."
				break;
			case error.TIMEOUT:
				x.innerHTML = "The request to get user location timed out."
				break;
			case error.UNKNOWN_ERROR:
				x.innerHTML = "An unknown error occurred."
				break;
		}
	}

	// Check if the users browser supports geolocation
				  
	if (navigator.geolocation)
	{
		// Get the user's location
		navigator.geolocation.getCurrentPosition(displayLocation, showError);

	}
	
	  // Display message if user's browswer doesn't support geolocation
	else {
		$("#usersLocation").html("Your browswer does not support geolocation.");
		return;
	}

});
