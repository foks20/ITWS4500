Samuel Fok
foks
661194875

Streaming Twitter API 

Technologies used:

//(Same technologies used in previous labs)
Server Backend:
-ExpressJs: Web application framework to build web application on node.js 
-socket.io: To communicate in realtime between backend server and frontend without refreshing page 
-twitter: nodejs library to stream data from Twitter 

Database
-MongoDB: data storage

Frontend:
-angularjs: Javascript framework on frontend to build UI 
-Bootstrap: Building website in responsive to have good looking on difference devices such as desktop browser, mobile browser, tablet browser....
-jQuery: Fast, small, and feature-rich JavaScript library 

Basic architecture of the app:
Expressjs to run web application/set up the server according to lab 5. 
Twitter nodejs library to stream data from Twitter into web application then use socket.io to transfer data in realtime once backend receive data from Twitter stream.
While tweets are streaming and loading up on your screen, tweets are being stored in the database at the same time.

If you try to load tweets from the database without streaming it first, you will get nothing as there is nothing in the database. 
So you must stream tweets first, and once you have done that, you can load tweets from the database with the "same name" that you searched when you try to stream for tweets.
The third button allows you to select json,csv or xml to export.

To start app, go to cmd(run it or run as admin), then locate the folder with the files and then type in: node server
Then go to localhost:3000 and you should see the tweets after you clicked on "search"

Sources used: class notes, stackoverflow, youtube, w3school, a bunch of videos from online,lots of example tutorials on converting json formt to csv format and also exporting it in xml format


