app.controller('FormController', function($scope, $http) {
	$scope.formData;
	$scope.submit = function(searchform) {
		if (searchform.$valid) {
			var searchString = '';
			var totalItem = 100;
			if ($scope.formData) {
				searchString = $scope.formData.search_string;
				totalItem = $scope.formData.total_item;
			}
			
			//if search box is empty, display a message of all tweets
			if(searchString===''){
				$('.text-success').html('Loading all Tweets');
					socket.emit('searchSubmit', {
					search_string: searchString,
					total_item: totalItem
				});
			}
			//displays a message corresponding to the searchbox
			else{ 
				$('.text-success').html('Watching Twitt for: ' + searchString);
				socket.emit('searchSubmit', {
				search_string: searchString,
				total_item: totalItem
				});
			}
		}
	}
	$scope.submitdb = function(searchformdb) {
		if (searchformdb.$valid) {
			var searchString = '';
			var totalItem = 100;
			if ($scope.formDatadb) {
				searchString = $scope.formDatadb.search_stringdb;
				totalItem = $scope.formDatadb.total_itemdb;
			}
			$('.text-success').html('Search Twitt for: ' + searchString);
			socket.emit('searchdbSubmit', {
				search_string: searchString,
				total_item: totalItem
			});
		}
	}
});