var mongoose = require('mongoose'); //require the library
mongoose.connect('mongodb://localhost/tweets'); //connect to mongodb on your localhost

var Schema = mongoose.Schema;

//define the Tweet Schema
var tweetsSchema = new Schema({
	created_at: Date,
	id: {type: String, unique : true, required : true, dropDups: true}, //save with unique id from Twitter
	text : String,
	user_id: String,
	user_name: String,
	user_screen_name: String,
	user_location: String,
	user_followers_count: String,
	user_friends_count: String,
	user_created_at: Date,
	user_time_zone: String,
	user_profile_background_color: String,
	user_profile_image_url: String,
	geo: String,
	coordinates: String,
	place: String
});

//export module
module.exports = {
	Tweets: mongoose.model('tweets', tweetsSchema)
};