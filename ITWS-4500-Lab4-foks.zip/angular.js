var app = angular.module('myApp', []);
app.controller('myCTRL',function($scope,$http){
	
	//using http to get the php file 
	$http({
		method: 'GET',
		url: 'get_tweets.php',
	    params: {'q':''}
		
	}).success(function(response){
		var i=0;
		//creating an array to store the information.
		$scope.data = [];
	
		for(i;i<14;i++){
			var tweets=response['statuses'][i]['text'];
			var screename=response['statuses'][i]['user']['screen_name'];
			var profileimage=response['statuses'][i]['user']['profile_image_url'];
		
			//calls the ng-repeat to dynamically make rows in the html file
			
			$scope.data.push({
				profileimage: profileimage,
				screenname: screename,
				tweet: tweets
			});
		}

	}, function myError(response){
			$scope.dataa=response.statusText;
	});
});
