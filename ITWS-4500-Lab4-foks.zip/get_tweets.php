<?php
require_once('TwitterAPIExchange.php');

$settings = array(
    'oauth_access_token' => '702967445003374594-UgoUVb37bQpyJHcjVePP9CVQ65BhxKo',
    'oauth_access_token_secret' => 'bjzdpfnzHih2XmbjvuOlo52W4sMGR4k2vPRSg9fLFhsLY',
    'consumer_key' => '9nALxgQGBFXvm4jMAU0RwFszG',
    'consumer_secret' => 'dSOjlpGoJHlQ8yxW1yRtj1cvg41gijKOhmf2JsnevYYh9wFNKA'
);

$url = "https://api.twitter.com/1.1/search/tweets.json";
$requestMethod = "GET";

$query = '?q=';
if(isset($_GET['q']) && $_GET['q']!='' ) {

    $query .= $_GET['q'];

} else {
    $query .= 'something';
}



//echo $query;
$twitter = new TwitterAPIExchange($settings);
$results = $twitter->setGetfield($query)->buildOauth($url, $requestMethod)->performRequest();
echo $results;
?>
