661194875	
foks
Samuel Fok

Web Science


I am using angular and bootstrap grid in html5. HTML5 is giving me errors when I tried to validate it. The error or complains 
is from the angular part. It is saying that these attributes are not allow in the div tag. It seem like ng-repeat only works
with <li> tag. Because of the lab we are required to use bootstrap instead of list or table, this is the only way I know 
that works.

As for the js file, I used angularjs.
After locating the profile picture, screen name and the tweets, I was able to display it onto my screen. 

So pretty much angularjs or the javascript file is the middle man, where it gets the info from the php file and then
extract the info specified and uses html to display the info.
Went and validated the js file. The php files given should be validated since they are files that I did not change except the secret codes.


As for css, I added some shadow and borders to make it look creative.
I've also used media queues and ensured that when window changes size or screen changes size the format will be adjusted.
I added some color to make it look nice.

As for the html file, I used bootstrap and angular. The bootstrap is used to make the grid.
Angular was used so that I can use the ng-repeat feature.

Resources: Stack over flow, bootstrap, w3 school, angularjs website, youtube, class notes and examples.