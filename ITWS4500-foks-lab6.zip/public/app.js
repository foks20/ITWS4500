//define angular app
'use strict';
var app = angular.module('myApp', []);