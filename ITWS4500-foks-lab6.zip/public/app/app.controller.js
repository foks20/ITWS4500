//angular code to control the view on index.html search input
app.controller('FormController', function($scope, $http) {
	$scope.formData;
	$scope.submit = function(searchform) {
		if (searchform.$valid) {
			var searchString = '';
			var totalItem = 100;
			if ($scope.formData) {
				searchString = $scope.formData.search_string;
				totalItem = $scope.formData.total_item;
			}
			$('.text-success').html('Loading Tweets with: ' + searchString);
			socket.emit('searchSubmit', {
				search_string: searchString,
				total_item: totalItem
			});
		}
	}
});