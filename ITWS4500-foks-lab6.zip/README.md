Samuel Fok
foks
661194875

Streaming Twitter API 

Technologies used:

//(Same technologies used in previous labs)
Server Backend:
-ExpressJs: Web application framework to build web application on node.js 
-socket.io: To communicate in realtime between backend server and frontend without refreshing page 
-twitter: nodejs library to stream data from Twitter 


Frontend:
-angularjs: Javascript framework on frontend to build UI 
-Bootstrap: Building website in responsive to have good looking on difference devices such as desktop browser, mobile browser, tablet browser....
-jQuery: Fast, small, and feature-rich JavaScript library 

Basic architecture of the app:
Expressjs to run web application/set up the server according to lab 5. 
Twitter nodejs library to stream data from Twitter into web application then use socket.io to transfer data in realtime once backend receive data from Twitter stream.


To start app, go to cmd(run it or run as admin), then locate the folder with the files and then type in: node server
Then go to localhost:3000 and you should see the tweets after you clicked on "search"

I am unable to figure out the error handling. When a user click on download/export. Whether the file exists or not, it will still download. If the file exist already in the same
directory, it still downloads and it automatically creates a new name for it... example csv, csv(1), csv(2), so on and so forth.

************************************************
Where should you put the conversion code?

The conversion code is in front end rather than back end as it has the ability to add more features in the future, such as:
maybe store/keep twitter data as local data on browser(what this does is that if you happen to be offline, users will have tweet data to see from their last visit)

The second reason is that it helps build the app in a shorter time!
************************************************

Sources used: class notes, stackoverflow, youtube, w3school, a bunch of videos from online,lots of example tutorials on converting json formt to csv format


