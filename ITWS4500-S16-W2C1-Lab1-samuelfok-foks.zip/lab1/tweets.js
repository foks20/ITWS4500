$(document).ready(function(e) {

   $.ajax({
     type: "GET",
     url: "tweetsFromTwitter.json",
     dataType: "json",

     success: function(responseData, status) {
		
		some(0);
		function some(amount) {
			var lili = document.getElementById("listoftweets");
			var childs = lili.childNodes.length;
			//checks if there are nodes or lists already, if so remove the first one
			//checking with 6 instead of 5 because for some reason it counts child as 1 instead of 0
			if (lili.childNodes.length == 6) {
				childs -= 1;
				//does the bootstrap animation of removing the first child node and then removes it
				$('#listoftweets').children('li').eq(0).css('-webkit-animation', 'removeds-item-animation 500ms');
				$('#listoftweets').children('li').eq(0).on('webkitAnimationEnd', function() {
					$('#listoftweets').children('li').eq(0).remove();
				});
			}
			//if length that is display is less than 5 then should loop through json and get the next one until it equals 5
			while (childs < 6) {
				var tweetinfo = responseData[amount].text;
				$('ul').append($("<li class='row'>").text(tweetinfo));
				amount += 1;
				childs += 1;
			}	
			//waits 3 seconds and calls the function to remove and add a new list to display
			setTimeout(function() {some(amount)}, 3000);
			}
        }, error: function(msg) {
        alert("There was a problem: " + msg.status + " " + msg.statusText);
        }

   });
});
